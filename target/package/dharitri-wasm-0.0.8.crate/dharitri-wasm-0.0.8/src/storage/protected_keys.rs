pub static DHARITRI_REWARD_KEY: &[u8] = &*b"DHARITRIreward";
