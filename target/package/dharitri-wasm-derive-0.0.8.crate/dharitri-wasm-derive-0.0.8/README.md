# dharitri-wasm-derive

Crate that contains all macro code generation for Dharitri smart contracts.

Note: slightly different code is generated in debug and release mode.
