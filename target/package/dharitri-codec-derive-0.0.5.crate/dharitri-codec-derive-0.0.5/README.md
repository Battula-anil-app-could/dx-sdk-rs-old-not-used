# dharitri-codec-derive

Crate that contains all macro code generation the dharitri-codec serializer.

There are 4 derive macros currently provided:
* NestedEncode
* NestedDecode
* TopEncode
* TopDecode

For more info about the serialization format, see [the developer reference](https://docs.dharitri.com/developers/developer-reference/dharitri-serialization-format/).
