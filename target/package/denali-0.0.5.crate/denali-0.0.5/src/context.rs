pub struct InterpreterContext {}

impl Default for InterpreterContext {
	fn default() -> Self {
		InterpreterContext {}
	}
}
