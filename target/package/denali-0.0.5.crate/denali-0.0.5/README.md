# denali-rs
Rust implementation of the Denali smart contract test format

Format specification: https://docs.dharitri.com/developers/developer-reference/denali-tests
